
public class Account {
	private int id = 0;
	private double balance = 0.0;
	private double annualInterestRate = 0.045;
	java.util.Date date = new java.util.Date();
	double withdraw = 0.0;
	double deposit = 0.0;
	
	Account() {
		
	}
	Account(int newid, double newbalance, double newwithdraw, double newdeposit){
		id = newid;
		balance = newbalance;
		withdraw = newwithdraw;
		deposit = newdeposit;
	}
	
	int getid() {
		return id;
	}
	double getbalance() {
		return (balance + (deposit - withdraw));
	}
	java.util.Date getdateCreated() {
		return date;
	}
	double getMonthlyInterestRate() {
		return (annualInterestRate / 12);
	}
	double getMonthlyInterest() {
		return (balance * (annualInterestRate/12));
	}
	
}

