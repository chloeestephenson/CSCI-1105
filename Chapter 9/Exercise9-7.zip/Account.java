/**
 * Author: Chloee Stephenson
 * Date: 8/30/19
 * Description: Account class
 */
public class Account {
	private int id = 0;
	private double balance = 0.0;
	private double annualInterestRate = 0.045;
	java.util.Date date = new java.util.Date();
	double withdraw = 0.0;
	double deposit = 0.0;
	Account() {
		
	}
	Account(int newid, double newbalance){
		id = newid;
		balance = newbalance;
	}
	
	int getid() {
		return id;
	}
	double getwithdraw(double newwithdraw) {
		return withdraw = newwithdraw;
	}
	double getdeposit(double newdeposit) {
		return deposit = newdeposit;
	}
	double getbalance() {
		return balance + (deposit - withdraw);
	}
	java.util.Date getdateCreated() {
		return date;
	}
	double getMonthlyInterestRate() {
		return (annualInterestRate / 12);
	}
	double getMonthlyInterest() {
		return (balance * (annualInterestRate/12));
	}
	
}