
public class Exercise9_1 {

	public static void main(String[] args) {
		
		System.out.println("The width of this rectangle is: " + new Rectangle(4, 40).getWidth());
		System.out.println("The height of this rectangle is: " + new Rectangle(4, 40).getHeight());
		System.out.println("The area of this rectangle is: " + new Rectangle(4, 40).getArea());
		System.out.println("The perimeter of this rectangle is: " + new Rectangle(4, 40).getPerimeter());
		
		System.out.println("");
		
		System.out.println("The width of this rectangle is: " + new Rectangle(3.5,35.9).getWidth());
		System.out.println("The height of this rectangle is: " + new Rectangle(3.5,35.9).getHeight());
		System.out.println("The area of this rectangle is: " + new Rectangle(3.5,35.9).getArea());
		System.out.println("The perimeter of this rectangle is: " + new Rectangle(3.5,35.9).getPerimeter());
		
	}

}
