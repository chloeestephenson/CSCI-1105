
public class Rectangle {
	double Width = 1.0;
	double Height = 1.0;
	//Constructor//
	Rectangle(){
		
	}
	Rectangle(double newWidth, double newHeight){
		Width = newWidth;
		Height = newHeight;
	}
	
	//Methods//
	double getArea() {
		return Width * Height;
	}
	double getPerimeter() {
		return ( 2 * Width) + ( 2 * Height);
		
	}
	double getHeight() {
		return Height;
	}
	double getWidth() {
		return Width;
	}
	
}
